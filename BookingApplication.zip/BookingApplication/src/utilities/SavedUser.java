package utilities;

import java.util.ArrayList;

public class SavedUser {
    String name = "Daniela";
    String lastName = "Dias";
    String id = "300319873";
    public SavedUser(){

    }

    public ArrayList<String> returnUser(){
        ArrayList<String> returnUser = new ArrayList<>();

        returnUser.add(name);
        returnUser.add(lastName);
        returnUser.add(id);
        return returnUser;
    }
}
