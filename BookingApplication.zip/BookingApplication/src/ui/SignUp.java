package ui;

import utilities.ExitListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class SignUp  extends JFrame {

    Container container = getContentPane();
    JPanel titlePanel = new JPanel(null);
    JPanel signUpPanel = new JPanel(null);

    JLabel labelFirtsName, labelDOB, labelLastName, labelID, labelUserName, labelPassword, labelTitle, labelSubtitle;
    JTextField fieldUserName, fieldFirstName, fieldLastName, fieldID;
    JPasswordField fieldPassword;
    JButton btnSignIn, btnSignUp;

    public SignUp(){

        container.setLayout(new BorderLayout());

        signUpPanel.setBackground(Color.WHITE);
        titlePanel.setBackground(Color.BLACK);

        titlePanel.setBounds(0,0,600,150);
        signUpPanel.setBounds(0,200,600,500);

        labelTitle = new JLabel("Welcome to VanFlights");
        labelTitle.setFont(new Font("Serif", Font.PLAIN, 24));
        labelTitle.setForeground(Color.white);
        labelSubtitle = new JLabel("User creation page");
        labelSubtitle.setForeground(Color.white);

        labelUserName = new JLabel("User Name: ");
        labelPassword = new JLabel("Password: ");
        labelFirtsName = new JLabel("First Name: ");
        labelDOB = new JLabel("Date of Birth: ");
        labelLastName = new JLabel("Last Name: ");
        labelID = new JLabel("ID: ");

        //DOB field
        fieldFirstName = new JTextField(20);
        fieldLastName = new JTextField(20);
        fieldUserName = new JTextField(20);
        fieldPassword = new JPasswordField(20);
        fieldID = new JTextField(20);
        btnSignIn = new JButton("Sign In");
        btnSignUp = new JButton("Sign Up");
        btnSignUp.setFont(new Font("Serif", Font.PLAIN, 16));

        labelTitle.setBounds(180, 50, 300, 30);
        labelSubtitle.setBounds(250, 80, 500, 21);
        labelFirtsName.setBounds(50, 200, 100, 21);
        fieldFirstName.setBounds(120, 200, 100, 21);
        labelLastName.setBounds(50, 250, 100, 21);
        fieldLastName.setBounds(120, 250, 100, 21);
        labelID.setBounds(50, 300, 100, 21);
        fieldID.setBounds(120, 300, 100, 21);
        labelUserName.setBounds(320, 200, 100, 21);
        fieldUserName.setBounds(400, 200, 100, 21);
        labelPassword.setBounds(320, 250, 100, 21);
        fieldPassword.setBounds(400, 250, 100, 21);
        labelDOB.setBounds(320, 300, 100, 21);
        //DOB
        btnSignUp.setBounds(240, 400, 100, 35);
        btnSignUp.setFocusPainted(false);
        btnSignUp.setBorderPainted(false);
        btnSignIn.setBounds(240, 440, 100, 25);
        btnSignIn.setBorderPainted(false);
        btnSignIn.setFocusPainted(false);
        btnSignIn.setBackground(Color.WHITE);

        titlePanel.add(labelTitle);
        titlePanel.add(labelSubtitle);
        signUpPanel.add(labelFirtsName);
        signUpPanel.add(fieldFirstName);
        signUpPanel.add(labelLastName);
        signUpPanel.add(fieldLastName);
        signUpPanel.add(labelUserName);
        signUpPanel.add(fieldUserName);
        signUpPanel.add(labelID);
        signUpPanel.add(fieldID);
        signUpPanel.add(labelPassword);
        signUpPanel.add(fieldPassword);
        signUpPanel.add(labelDOB);
        //signUpPanel.add(fieldDOB);
        signUpPanel.add(btnSignUp);
        signUpPanel.add(btnSignIn);

        container.add(titlePanel);
        container.add(signUpPanel);

        pack();
        setSize(600,600);
        setVisible(true);

        btnSignIn.addActionListener(new returnSignIn(container));
    }
}

class returnSignIn implements ActionListener {

    Container container;

    public returnSignIn(Container container)
    {
        this.container = container;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Make transition
        JOptionPane.showMessageDialog(null, "Transition to SignIn");
        Login transition = new Login();
        container.setVisible(false);
    }

}
