package ui;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

public class Booking extends JFrame {
    Container container = getContentPane();
    JPanel titlePanel = new JPanel(null);
    JPanel bookingPanel = new JPanel(null);

    JLabel labelTo, labelFrom, labelDeparture, labelAdult, labelChild,labelPassengers, labelTitle;
    JComboBox flightsFrom, flightsTo, month, adultSeats, childSeats;
    JTextField day;
    JButton btnFindFlights;
    //Toggle

    public Booking(){

        //String list is for testing must inplement database here
        String[] origins = {"Vancouver", "Richmond", "Nanaimo", "Victoria"};
        String[] destinations = {"Vancouver", "Nanaimo", "Victoria"};
        String[] allMonths = {"January", "February", "March", "April", "May"};
        String[] adultSeating = {"1", "2", "3", "4", "5"};
        String[] childSeating = {"0", "1", "2", "3", "4", "5"};

        container.setLayout(new BorderLayout());

        titlePanel.setBackground(Color.BLACK);
        bookingPanel.setBackground(Color.WHITE);

        titlePanel.setBounds(0,0,800,150);
        bookingPanel.setBounds(0,200,800,600);

        labelTitle = new JLabel("Search Flights");
        labelTitle.setFont(new Font("Serif", Font.PLAIN, 24));
        labelTitle.setForeground(Color.white);

        labelTo = new JLabel("To: ");
        flightsTo = new JComboBox(destinations);
        labelFrom = new JLabel("From: ");
        flightsFrom = new JComboBox(origins);
        labelDeparture = new JLabel("Departure: ");
        day = new JTextField(5);
        month = new JComboBox(allMonths);
        labelPassengers = new JLabel("Passengers");
        labelAdult = new JLabel("Adult");
        adultSeats = new JComboBox(adultSeating);
        labelChild = new JLabel("Child");
        childSeats = new JComboBox(childSeating);
        btnFindFlights = new JButton("Search Flights");

        labelTitle.setBounds(220, 50, 300, 30);
        labelFrom.setBounds(50, 200, 100, 21);
        flightsFrom.setBounds(120, 200, 100, 21);
        labelTo.setBounds(50, 250, 100, 21);
        flightsTo.setBounds(120, 250, 100, 21);
        labelDeparture.setBounds(50, 300, 100, 21);
        day.setBounds(120, 300, 20, 21);
        month.setBounds(150,300, 100, 21);
        labelPassengers.setBounds(400, 200, 100, 21);
        labelPassengers.setFont(new Font("Serif", Font.BOLD, 12));
        labelAdult.setBounds(400, 250, 100, 21);
        adultSeats.setBounds(450, 250, 50, 21);
        labelChild.setBounds(400, 300, 100, 21);
        childSeats.setBounds(450, 300, 50, 21);
        btnFindFlights.setBounds(250, 400, 100, 21);

        titlePanel.add(labelTitle);
        bookingPanel.add(flightsTo);
        bookingPanel.add(labelTo);
        bookingPanel.add(flightsFrom);
        bookingPanel.add(labelFrom);
        bookingPanel.add(labelDeparture);
        bookingPanel.add(day);
        bookingPanel.add(month);
        bookingPanel.add(labelPassengers);
        bookingPanel.add(labelAdult);
        bookingPanel.add(adultSeats);
        bookingPanel.add(labelChild);
        bookingPanel.add(childSeats);
        bookingPanel.add(btnFindFlights);

        container.add(titlePanel);
        container.add(bookingPanel);

        pack();
        setSize(600,600);
        setVisible(true);

        //Button
        btnFindFlights.addActionListener(new goToReservation(container, this));
        //btnSignIn.addActionListener(new returnSignIn(container));
    }

}

class goToReservation implements ActionListener {

    Container container;
    Booking booking;


    public goToReservation(Container container, Booking booking)
    {
        this.booking = booking;
        this.container = container;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        //Make transition
        Reservation reservation = new Reservation(booking);
        container.setVisible(false);
    }
}

