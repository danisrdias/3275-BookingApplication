package ui;

import utilities.ExitListener;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;

public class Reservation  extends JFrame {
    Container container = getContentPane();
    JPanel flightsPanel = new JPanel(null);
    JPanel reservationPanel= new JPanel(null);
    JPanel titlePanel= new JPanel(null);;

    JLabel labelTitle, labelSelectFligh, labeltotalAmount, labelnumberOfPassengers, outputAmount, outputNOfPassengers;
    JTable table;
    JComboBox flights;
    JButton btnProceedWithBooking;

    Object[] flightOne = {"VAN3001", "Vancouver", "Victoria", "8:00 AM", "8:30AM", "CAD 150.00", "10"};
    Object[] flighttWO = {"VAN5001", "Vancouver", "Nanaimo", "8:00 AM", "8:30AM", "CAD 150.00", "10"};
    Object[][] flightsInformation = {flightOne, flighttWO};

    Booking booking;
    Integer totalSeats = 1;

    public Reservation(Booking booking){
        container.setLayout(new BorderLayout());

        titlePanel.setBackground(Color.BLACK);
        flightsPanel.setBackground(Color.WHITE);
        reservationPanel.setBackground(Color.WHITE);

        titlePanel.setBounds(0,0,800,150);
        flightsPanel.setBounds(0,150,800,250);
        reservationPanel.setBounds(0,350,800,250);

        this.booking = booking;

        getUserInput();

        labelTitle = new JLabel("Make a Reservation");
        labelTitle.setFont(new Font("Serif", Font.PLAIN, 24));
        labelTitle.setForeground(Color.white);


        final Object[] header = {"Flight", "From", "To", "Departure", "Arrival", "Price", "Seats Available"};
        table = new JTable(loadFlights(), header);
        JScrollPane scrollPane = new JScrollPane(table, ScrollPaneConstants.VERTICAL_SCROLLBAR_AS_NEEDED, ScrollPaneConstants.HORIZONTAL_SCROLLBAR_AS_NEEDED);

        labelSelectFligh = new JLabel("Please Select a Flight");
        String[] flightCode = {"","VAN5001", "VAN3001"};
        flights = new JComboBox(flightCode);
        labelnumberOfPassengers = new JLabel("No. of Passengers: ");
        outputNOfPassengers = new JLabel(totalSeats.toString());
        labeltotalAmount = new JLabel("Total Amount: ");
        outputAmount = new JLabel("");
        btnProceedWithBooking = new JButton("Next");

        labelTitle.setBounds(300, 50, 300, 30);
        scrollPane.setBounds(100,20,600,150);
        scrollPane.setVisible(true);
        labelSelectFligh.setBounds(250, 400, 200, 21);
        flights.setBounds(450, 400, 100, 21);
        labelnumberOfPassengers.setBounds(150, 450, 150, 21);
        outputNOfPassengers.setBounds(250, 450, 100, 21);
        labeltotalAmount.setBounds(150, 500, 150, 21);
        outputAmount.setBounds(250, 500, 150, 21);
        btnProceedWithBooking.setBounds(400, 500, 150, 21);

        titlePanel.add(labelTitle);
        flightsPanel.add(scrollPane);
        reservationPanel.add(labelSelectFligh);
        reservationPanel.add(flights);
        reservationPanel.add(labelnumberOfPassengers);
        reservationPanel.add(outputNOfPassengers);
        reservationPanel.add(labeltotalAmount);
        reservationPanel.add(outputAmount);
        reservationPanel.add(btnProceedWithBooking);


        container.add(titlePanel);
        container.add(flightsPanel);
        container.add(reservationPanel);

        pack();
        setSize(800,600);
        setVisible(true);

        addWindowListener(new ExitListener());
        flights.addActionListener(new itemSelected(this));

        btnProceedWithBooking.addActionListener(new goToTicket(container, booking, this));
    }


    public ArrayList<String> getUserInput(){
        ArrayList<String> userInformation = new ArrayList<>();

        String adultPassengers = (String)booking.adultSeats.getSelectedItem();
        String childSeats = (String)booking.childSeats.getSelectedItem();

        //Get Total Seats
        totalSeats = Integer.parseInt(adultPassengers) + Integer.parseInt(childSeats);

        userInformation.add((String)booking.flightsFrom.getSelectedItem());
        System.out.println((String)booking.flightsFrom.getSelectedItem());
        return userInformation;
    }


    public Object[][] loadFlights(){
        return flightsInformation;
    }
}

class itemSelected implements ActionListener {
    Reservation reservation;
    //implement check passport and check user

    public itemSelected(Reservation reservation)
    {
        this.reservation = reservation;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //Get variables from user input
        String flight = (String)reservation.flights.getSelectedItem();

        //Here Check Database and Return Item Selected
        //Check the price of the item selected
        //Parse Value to Int
        int passengers = (int) reservation.totalSeats;

        //I fixed it here because there is no db to search from
        //Calculate total Amount
        double totalAmount = 0.0;
        if(flight!= ""){
            if(flight == "VAN3001")
                totalAmount = passengers * 150.00;
            else totalAmount= passengers * 190.00;
        }

        System.out.println(reservation.outputAmount.getText() + "Output 0");
        reservation.outputAmount.setText(String.valueOf(totalAmount));
        reservation.reservationPanel.add(reservation.outputAmount);
        reservation.container.validate();
        reservation.container.repaint();

        System.out.println(flight);
        System.out.println(passengers);
        System.out.println(reservation.outputAmount.getText());

    }
}

class goToTicket implements ActionListener {

    Container container;
    Booking booking;
    Reservation reservation;


    public goToTicket(Container container, Booking booking, Reservation reservation)
    {
        this.reservation = reservation;
        this.booking = booking;
        this.container = container;
    }


    @Override
    public void actionPerformed(ActionEvent e) {
        //Make transition
        //Needs flight information

        String flightSelected = reservation.flights.getSelectedItem().toString();
        String noOfPassengers = reservation.totalSeats.toString();
        String totalAmount = String.valueOf(reservation.outputAmount.getText());
        String day = booking.day.getText();
        String month = booking.month.getSelectedItem().toString();
        String date = day + " / " + month;

        //Will filter db and get the flight information
        ArrayList<String> flightOne = new ArrayList<>();
        flightOne.add("VAN3001");
        flightOne.add("Vancouver");
        flightOne.add("Victoria");
        flightOne.add("8:00 AM");
        flightOne.add("8:30AM");
        flightOne.add("CAD 150.00");
        flightOne.add("10");

        //Filter database based on flight from combobox
        System.out.println(noOfPassengers);
        System.out.println(totalAmount);
        System.out.println(day);
        System.out.println(month);


        Ticket ticket = new Ticket(flightOne, noOfPassengers, totalAmount, date);

        container.setVisible(false);
    }
}