package ui;

import utilities.SavedUser;

import javax.swing.*;
import java.awt.*;
import java.util.ArrayList;

public class Ticket extends JFrame {

    Container container = getContentPane();
    JPanel ticketPanel= new JPanel(null);
    JPanel titlePanel= new JPanel(null);;

    JLabel labelTitle, labelFlight, labelFrom, labelTo, labelDeparture, laberArrival,
            labeltotalAmount, labelnumberOfPassengers, labelName, labelID, labelProceed, labelDate;
    JLabel outputFlight, outputFrom, outputTo, outputDeparture, outputArrival,
           outputAmount, outputNOfPassengers, outputName, outputID, outputDate;
    JButton btnFinalizeReservation;


    public Ticket(ArrayList<String> flightInformation, String nOfPassengers, String totalAmount, String date){


        container.setLayout(new BorderLayout());

        titlePanel.setBackground(Color.BLACK);
        ticketPanel.setBackground(Color.WHITE);

        titlePanel.setBounds(0,0,800,150);
        ticketPanel.setBounds(0,200,800,800);

        labelTitle = new JLabel("Book Now");
        labelTitle.setFont(new Font("Serif", Font.PLAIN, 24));
        labelTitle.setForeground(Color.white);

        // Get Name and ID
        SavedUser user = new SavedUser();
        ArrayList<String> userInformation = user.returnUser();

        labelFlight = new JLabel("Flight Number: ");
        outputFlight = new JLabel(flightInformation.get(0));
        labelTo = new JLabel("To: ");
        outputTo = new JLabel(flightInformation.get(2));
        labelFrom = new JLabel("From: ");
        outputFrom = new JLabel(flightInformation.get(1));
        labelDeparture = new JLabel("Departure Time: ");
        outputDeparture = new JLabel(flightInformation.get(3));
        laberArrival = new JLabel("Arrival Time:");
        outputArrival = new JLabel(flightInformation.get(4));
        labelnumberOfPassengers = new JLabel("Number of Passengers");
        outputNOfPassengers = new JLabel(nOfPassengers);
        labelName = new JLabel("Name: ");
        outputName = new JLabel(userInformation.get(0) + " " + userInformation.get(1));
        labelID = new JLabel("ID: ");
        outputID = new JLabel(userInformation.get(2));
        labeltotalAmount = new JLabel("Total Booking Amount: ");
        outputAmount  = new JLabel(totalAmount);
        labelDate = new JLabel("Date: ");
        outputDate = new JLabel(date);
        labelProceed = new JLabel("Please arrive 1 hour before your booking for payment proceeding and ID checking");
        btnFinalizeReservation = new JButton("Proceed with Booking");

        labelTitle.setBounds(220, 50, 300, 30);

        labelFlight.setBounds(50, 200, 100, 21);
        outputFlight.setBounds(150, 200, 100, 21);
        labelFrom.setBounds(50, 250, 100, 21);
        outputFrom.setBounds(120, 250, 100, 21);
        labelTo.setBounds(50, 300, 100, 21);
        outputTo.setBounds(120, 300, 100, 21);
        labelDeparture.setBounds(335, 250, 100, 21);
        outputDeparture.setBounds(450, 250, 100, 21);
        laberArrival.setBounds(335, 300, 100, 21);
        outputArrival.setBounds(450, 300, 100, 21);
        labelDate.setBounds(50, 350, 100, 21);
        outputDate.setBounds(120, 350, 100, 21);
        labelName.setBounds(50, 400, 100, 21);
        outputName.setBounds(120, 400, 100, 21);
        labelID.setBounds(50, 450, 100, 21);
        outputID.setBounds(120, 450, 100, 21);
        labelnumberOfPassengers.setBounds(50, 500, 150, 21);
        outputNOfPassengers.setBounds(200, 500, 150, 21);
        labeltotalAmount.setBounds(50, 550, 150, 21);
        outputAmount.setBounds(200, 550, 100, 21);
        labelProceed.setBounds(50, 600, 400, 21);
        btnFinalizeReservation.setBounds(150, 680, 200, 21);

        titlePanel.add(labelTitle);
        ticketPanel.add(labelFlight);
        ticketPanel.add(outputFlight);
        ticketPanel.add(labelFrom);
        ticketPanel.add(outputFrom);
        ticketPanel.add(labelTo);
        ticketPanel.add(outputTo);
        ticketPanel.add(labelDeparture);
        ticketPanel.add(outputDeparture);
        ticketPanel.add(laberArrival);
        ticketPanel.add(outputArrival);
        ticketPanel.add(labelDate);
        ticketPanel.add(outputDate);
        ticketPanel.add(labelName);
        ticketPanel.add(outputName);
        ticketPanel.add(labelID);
        ticketPanel.add(outputID);
        ticketPanel.add(labelnumberOfPassengers);
        ticketPanel.add(outputNOfPassengers);
        ticketPanel.add(labeltotalAmount);
        ticketPanel.add(outputAmount);
        ticketPanel.add(labelProceed);
        ticketPanel.add(btnFinalizeReservation);

        container.add(titlePanel);
        container.add(ticketPanel);

        pack();
        setSize(600,800);
        setVisible(true);

    }

}
