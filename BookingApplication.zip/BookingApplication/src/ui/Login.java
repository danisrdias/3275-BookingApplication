package ui;

import utilities.ExitListener;
import utilities.WindowsUtilities;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


public class Login extends JFrame {

    Container container = getContentPane();
    JPanel loginPanel = new JPanel(null);
    JPanel loginTitlePanel = new JPanel(null);

    JLabel labelUserName, labelPassword, labelTitle, labelSubtitle;
    JTextField fieldUserName;
    JPasswordField fieldPassword;
    JButton btnSignIn, btnSignUp;

    public Login(){
        WindowsUtilities.setNativeLookAndFeel();
        setPreferredSize(new Dimension(600, 500));

        loginPanel.setBackground(Color.WHITE);
        loginTitlePanel.setBackground(Color.BLACK);

        loginTitlePanel.setBounds(0,0,600,150);
        loginPanel.setBounds(0,200,600,400);

        labelTitle = new JLabel("Welcome to VanFlights");
        labelTitle.setFont(new Font("Serif", Font.PLAIN, 24));
        labelTitle.setForeground(Color.white);
        labelSubtitle = new JLabel("Fly in style with our seaplanes and see the best of what British Columbia has to offer!");
        labelSubtitle.setForeground(Color.white);
        labelUserName = new JLabel("User Name: ");
        labelPassword = new JLabel("Password: ");
        fieldUserName = new JTextField(15);
        fieldPassword = new JPasswordField(15);
        btnSignIn = new JButton("Sign In");
        btnSignIn.setFont(new Font("Serif", Font.PLAIN, 16));
        btnSignUp = new JButton("Sign Up");

        labelTitle.setBounds(180, 50, 300, 30);
        labelSubtitle.setBounds(90, 80, 500, 21);
        labelUserName.setBounds(190, 200, 100, 21);
        fieldUserName.setBounds(280, 200, 100, 21);
        labelPassword.setBounds(190, 250, 100, 21);
        fieldPassword.setBounds(280, 250, 100, 21);
        btnSignIn.setBounds(240, 300, 100, 25);
        btnSignIn.setFocusPainted(false);
        btnSignIn.setBorderPainted(false);
        btnSignUp.setBounds(240, 330, 100, 25);
        btnSignUp.setBorderPainted(false);
        btnSignUp.setFocusPainted(false);
        btnSignUp.setBackground(Color.WHITE);

        loginTitlePanel.add(labelTitle);
        loginTitlePanel.add(labelSubtitle);
        loginPanel.add(labelUserName);
        loginPanel.add(fieldUserName);
        loginPanel.add(labelPassword);
        loginPanel.add(fieldPassword);
        loginPanel.add(btnSignIn);
        loginPanel.add(btnSignUp);

        container.add(loginTitlePanel);
        container.add(loginPanel);

        pack();
        setVisible(true);

        addWindowListener(new ExitListener());

        btnSignIn.addActionListener(new signInButton(this));
        btnSignUp.addActionListener(new signUpButton(this));

    }
}

//Button control
class signInButton implements ActionListener{

    Login login;

    //implement check passport and check user
    char[] inputPassword, adminPassword={'a','d','m','i','n', '\0'};
    String inputUserName, adminUser = "admin";

    public signInButton(Login login)
    {
        this.login = login;
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //Get variables from user input
        inputPassword = login.fieldPassword.getPassword();
        inputUserName = login.fieldUserName.getText();
        System.out.println(inputUserName);

        if(inputUserName.equals(adminUser) && check()){

            //Navigate to Next Page
            Booking transition = new Booking();
        }
        else {
            JOptionPane.showMessageDialog(null, "Invalid username or password. Try again");
        }
    }
    public boolean check()
    {
        //TODO: Implement Check Method
/*        if (inputUserName.length() >= 6 || inputUserName.length() < 4)
            return false;
        for(int i=0;i<=4;i++)
        {
            if(inputUserName[i]!=inputPassword[i]){return false;}

        }*/
        return true;
    }
}

class signUpButton implements ActionListener{

    //Login login;
    Container container;

    public signUpButton(Container container)
    {
        //this.login = login;
        this.container = container;
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        //Make transition
        JOptionPane.showMessageDialog(null, "Transition to SignUp");
        SignUp transition = new SignUp();
        container.setVisible(false);
    }

}



/*
class signUp extends MouseAdapter
{
    Login login;

    public signUp(Login login)
    {
        this.login = login;
    }
    public void mouseEntered(MouseEvent e)
    {
        login.btnSignUp.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
    }
    public void mouseClicked(MouseEvent e)
    {
       new SignUp(login);
    }
}
*/
